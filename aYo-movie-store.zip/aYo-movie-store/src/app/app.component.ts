import { Component } from '@angular/core';
import { SwUpdate } from '@angular/service-worker';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'movie-store';

constructor( private update: SwUpdate) {
    this.updateClient();
}
  /**
   * Method to update user, if there any chanegs happend in appication / any new changes pushed to the server
   * @returns 
   */
  updateClient() {
    if(!this.update.isEnabled) {
      console.log("SwUpdate is not enabled");
      return;
    }
    this.update.available.subscribe((event) => {
      console.log("current", event.current, "available", event.available);
      if(confirm("Update is available, Please confirm to make the changes")) {
        this.update.activateUpdate().then(() => location.reload());
      }
    });

    this.update.activated.subscribe((event) => {
      console.log("current", event.previous, "available", event.current);
    })
  }
}
