export default class Utils {

  // Function to use in multiple places
  static getImageOrFallback(url: string, fallback: string) {
    return new Promise((resolve, reject) => {
      const img = new Image()
      img.src = url
      img.onload = () => resolve(url)
      img.onerror = () => {
        reject(`image not found for url ${url}`)
      }
    }).catch(() => {
      return fallback
    })
  }
}