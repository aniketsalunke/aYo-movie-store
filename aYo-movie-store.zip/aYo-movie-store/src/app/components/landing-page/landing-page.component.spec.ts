import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { LandingPageComponent } from './landing-page.component';
import { ServiceWorkerModule } from '@angular/service-worker';

describe('LandingPageComponent', () => {
  let component: LandingPageComponent;
  let fixture: ComponentFixture<LandingPageComponent>;
  let moviesMockData: any;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LandingPageComponent ],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        ServiceWorkerModule.register('ngsw-worker.js', { enabled: false })
      ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    moviesMockData = {
      "Search": [
        {
          "Title": "Inception",
          "Year": "2010",
          "imdbID": "tt1375666",
          "Type": "movie",
          "Poster": "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg"
        },
        {
          "Title": "Inception: The Cobol Job",
          "Year": "2010",
          "imdbID": "tt5295894",
          "Type": "movie",
          "Poster": "https://m.media-amazon.com/images/M/MV5BMjE0NGIwM2EtZjQxZi00ZTE5LWExN2MtNDBlMjY1ZmZkYjU3XkEyXkFqcGdeQXVyNjMwNzk3Mjk@._V1_SX300.jpg"
        },
        {
          "Title": "Inception: Jump Right Into the Action",
          "Year": "2010",
          "imdbID": "tt5295990",
          "Type": "movie",
          "Poster": "https://m.media-amazon.com/images/M/MV5BZGFjOTRiYjgtYjEzMS00ZjQ2LTkzY2YtOGQ0NDI2NTVjOGFmXkEyXkFqcGdeQXVyNDQ5MDYzMTk@._V1_SX300.jpg"
        },
        {
          "Title": "The Crack: Inception",
          "Year": "2019",
          "imdbID": "tt6793710",
          "Type": "movie",
          "Poster": "https://m.media-amazon.com/images/M/MV5BZTU1M2U4OWUtZTQ5OS00OWM1LTljN2EtMWJmZDgxNzUwZGNkXkEyXkFqcGdeQXVyMTA0MjU0Ng@@._V1_SX300.jpg"
        },
        {
          "Title": "Inception: Motion Comics",
          "Year": "2010–",
          "imdbID": "tt1790736",
          "Type": "series",
          "Poster": "https://m.media-amazon.com/images/M/MV5BNGRkYzkzZmEtY2YwYi00ZTlmLTgyMTctODE0NTNhNTVkZGIxXkEyXkFqcGdeQXVyNjE4MDMwMjk@._V1_SX300.jpg"
        },
        {
          "Title": "Cyberalien: Inception",
          "Year": "2017",
          "imdbID": "tt7926130",
          "Type": "movie",
          "Poster": "N/A"
        }
      ],
      "totalResults": "32",
      "Response": "True"
    }
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should check if setListOfDetails method is mapping the incorrectly URL`, () => {
    spyOn(component, 'setListOfDetails').and.callThrough();
    component.setListOfDetails(moviesMockData);
    expect(component.setListOfDetails).toHaveBeenCalled();
    expect(moviesMockData['Search'][5].Poster).toEqual("https://picsum.photos/300/444");
  });

  it(`should check if setListOfDetails method is not making any changes to valid URL`, () => {
    spyOn(component, 'setListOfDetails').and.callThrough();
    component.setListOfDetails(moviesMockData);
    expect(component.setListOfDetails).toHaveBeenCalled();
    expect(moviesMockData['Search'][4].Poster).toEqual("https://m.media-amazon.com/images/M/MV5BNGRkYzkzZmEtY2YwYi00ZTlmLTgyMTctODE0NTNhNTVkZGIxXkEyXkFqcGdeQXVyNjE4MDMwMjk@._V1_SX300.jpg");
  });

  it(`should check if clearErrorMsg method is clearing the error banner`, () => {
    spyOn(component, 'clearErrorMsg').and.callThrough();
    component.clearErrorMsg();
    expect(component.clearErrorMsg).toHaveBeenCalled();
    expect(component.errorMessage).toEqual("");
    expect(component.showError).toBeFalse;
  });
});
