import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import Utils from 'src/app/utility/utils.component';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {

  seachText: string = "";
  seachYear: string = "";
  selectedValue: string = "";
  errorMessage: string = "";
  movieDetails: any = [];
  showError: boolean = false;
  showFilter: boolean = false;
  // movie type dropdown values
  movieType: any[] = [
    { value: 'movie', viewValue: 'Movie' },
    { value: 'series', viewValue: 'Series' },
    { value: 'episode', viewValue: 'Episode' },
  ];
  // slider image array
  imageObject = [{
    image: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/5.jpg',
    thumbImage: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/5.jpg'
  }, {
    image: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/9.jpg',
    thumbImage: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/9.jpg'
  }, {
    image: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/4.jpg',
    thumbImage: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/4.jpg'
  }];

  constructor(
    private commonService: CommonService,
    private _router: Router) {
     }

  ngOnInit(): void {
    //default value to search on page load
    let searchValue = "inception"
    this.getAllMovieDetails(searchValue);
  }

  /**
   * Method to list of searched movies/episodes/seasons
   * @param text - searched text, year(optional) and type(optional)
   * @returns list of searched movies/episodes/seasons
   */
  getAllMovieDetails(text: any) {
    if (!text) { return; }
    let inputObj = {
      title: text,
      apikey: "f7fca797",
      movieType: this.selectedValue,
      year: this.seachYear
    }
    this.commonService.getMovies(inputObj).subscribe((res: any) => {
      if (res.Search) {
        this.showError = false;
        this.setListOfDetails(res);
      } else {
        this.showError = true;
        this.errorMessage = res.Error;
      }
    }, err => {
      console.log("error", err);
    }
    )
  }

  /**
   * Method to set / map all the API data.
   * @param res 
   */
  setListOfDetails(res: any) {
    res.Search.forEach((el: any) => {
      // logic to assign random image if image is not present
      if (el.Poster == "N/A") {
        el.Poster = "https://picsum.photos/300/444";
      } else {
        // method to check if the image link is valid otherwise set the random images
        Utils.getImageOrFallback(el.Poster, "https://picsum.photos/400/300").then(validUrl => {
          if (validUrl != el.Poster) {
            el.Poster = "https://picsum.photos/300/444";
          }
        })
      }
    });
    this.movieDetails = res.Search;
  }

  /**
   * Method to navigate on details screen with id
   * @param imdbID 
   */
  navigateToDetails(imdbID: string) {
    this._router.navigate(['details'], { state: { id: imdbID } });
  }

  /**
   * Method to clear error message banner
   */
  clearErrorMsg() {
    this.errorMessage = "";
    this.showError = false;
  }

}
