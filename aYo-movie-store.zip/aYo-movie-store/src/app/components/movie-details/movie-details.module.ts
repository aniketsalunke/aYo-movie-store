import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowDetailsComponent } from './show-details/show-details.component';
import { MovieDetailsRoutingModule } from './movie-details-routing.module';

@NgModule({
  imports: [
    CommonModule,
    MovieDetailsRoutingModule
  ],
  declarations: [ShowDetailsComponent]
})
export class MovieDetailsModule { }
