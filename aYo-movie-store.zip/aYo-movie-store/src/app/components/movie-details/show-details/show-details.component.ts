import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { Location } from '@angular/common';
import Utils from 'src/app/utility/utils.component';

@Component({
  selector: 'app-show-details',
  templateUrl: './show-details.component.html',
  styleUrls: ['./show-details.component.scss']
})
export class ShowDetailsComponent implements OnInit {

  showDetails: any[] = [];
  id: string = "";
  posterLink: string = "";
  movieTitle: string = "";

  constructor(private commonService: CommonService, private location: Location) {
    // to get the data from route
    let respObj: any = this.location.getState();
    this.id = respObj?.id;
  }

  ngOnInit(): void {
    this.getShowDetails();
  }

  /**
   * Method to get the specific details and show on screen
   */
  getShowDetails() {
    let inputObj = {
      id: this.id,
      apikey: "f7fca797"
    }
    this.commonService.getMovieDetails(inputObj).subscribe((res: any) => {
      // logic to assign random image if image is not present
        if (res.Poster == "N/A") {
          res.Poster = "https://picsum.photos/300/444";
        } else {
          // method to check if the image link is valid otherwise set the random images
          Utils.getImageOrFallback(res.Poster, "https://picsum.photos/400/300").then(validUrl => {
            if (validUrl != res.Poster) {
              res.Poster = "https://picsum.photos/300/444";
            }
          })
        }
        this.posterLink = res.Poster;
        this.movieTitle = res.Title;
        // setting details in array to show on screen
        this.showDetails.push(
          { label: 'Title', value: res.Title },
          { label: 'Type', value: res.Type },
          { label: 'Year', value: res.Year },
          { label: 'Released', value: res.Released },
          { label: 'Runtime', value: res.Runtime },
          { label: 'Genre', value: res.Genre },
          { label: 'Director', value: res.Director },
          { label: 'Writer', value: res.Writer },
          { label: 'Actors', value: res.Actors },
          { label: 'Language', value: res.Language },
          { label: 'Country', value: res.Country },
          { label: 'Awards', value: res.Awards },
          { label: 'BoxOffice Collection', value: res.BoxOffice },
          { label: 'Metascore', value: res.Metascore },
          { label: 'imdbRating', value: res.imdbRating },     
        )
    }, err => {
      console.log("error", err);
    }
    )
  }

}
