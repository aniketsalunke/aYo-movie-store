import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  constructor(private httpClient: HttpClient) { }

  /**
   * Method to get list of movie/season/episode
   * @param input - apikey, title, movieType, year
   * @returns list of movies based on search result
   */
  getMovies(input: any) {
    input.movieType = input.movieType ? input.movieType : "";
    input.year = input.year ? input.year : "";
    return this.httpClient.get(`http://www.omdbapi.com/?apikey=${input.apikey}&s=${input.title}&type=${input.movieType}&y=${input.year}`);
  }

  /**
   * Method to get details of specific movie/season/episode
   * @param input  - apikey, imdbId
   * @returns details of specific movie/season/episode
   */
  getMovieDetails(input: any) {
    return this.httpClient.get(`http://www.omdbapi.com/?apikey=${input.apikey}&i=${input.id}`);
  }
}
