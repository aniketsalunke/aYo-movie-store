import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ServiceWorkerModule, SwUpdate } from '@angular/service-worker';
import { NgImageSliderModule } from 'ng-image-slider'
import { Subject } from 'rxjs';
import { AppComponent } from './app.component';

class MockSwUpdate {
  available = new Subject<{ available: { hash: string } }>().asObservable();
  activated = new Subject<{ current: { hash: string } }>().asObservable();

  public checkForUpdate(): Promise<void> {
    console.log('This is not working');
    return new Promise((resolve) => resolve());
  }
  public activateUpdate(): Promise<void> {
    return new Promise((resolve) => resolve());
  }

  constructor(public isEnabled: boolean) {
  }
}

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgImageSliderModule,
        ServiceWorkerModule.register('', {enabled: false})
      ],
      providers: [
        {provide: SwUpdate, useValue: MockSwUpdate}
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'movie-store'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('movie-store');
  });

});
